# scripts/descobrir_temas.py
"""
Descobre temas nos tickets usando clustering.
Gera relatório pra analista rotular.
"""
import sqlite3
from pathlib import Path

import hdbscan
import pandas as pd
import umap
from sentence_transformers import SentenceTransformer

RAIZ = Path(__file__).resolve().parent.parent
BANCO = RAIZ / 'dados' / 'tickets.db'
SAIDA = RAIZ / 'relatorios' / 'clusters.csv'

# ==================== 1. CARREGA TICKETS ====================
print('📂 Carregando tickets...')
conn = sqlite3.connect(BANCO)
df = pd.read_sql('''
    SELECT id, titulo, descricao, categoria
    FROM tickets
    WHERE criado_data >= date('now', '-1 year')
''', conn)
conn.close()

print(f'   {len(df)} tickets')

# ==================== 2. GERA EMBEDDINGS ====================
print('\n🧠 Gerando embeddings...')
model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

# Concatena título + descrição (limita tamanho)
textos = (
    df['titulo'].fillna('') + ' ' +
    df['descricao'].fillna('').str.slice(0, 500)
).tolist()

embeddings = model.encode(textos, show_progress_bar=True)
print(f'   Shape: {embeddings.shape}')

# ==================== 3. REDUZ DIMENSÃO ====================
print('\n📉 Reduzindo dimensão (UMAP)...')
umap_emb = umap.UMAP(
    n_neighbors=15,
    n_components=5,
    min_dist=0.0,
    metric='cosine',
    random_state=42,
).fit_transform(embeddings)

# ==================== 4. CLUSTERING ====================
print('\n🔍 Agrupando (HDBSCAN)...')
clusterer = hdbscan.HDBSCAN(
    min_cluster_size=20,   # mínimo 20 tickets por grupo
    min_samples=5,
    metric='euclidean',
    cluster_selection_method='eom',
)
clusters = clusterer.fit_predict(umap_emb)

df['cluster'] = clusters

n_clusters = len(set(clusters)) - (1 if -1 in clusters else 0)
n_ruido = (clusters == -1).sum()
print(f'   {n_clusters} clusters encontrados')
print(f'   {n_ruido} tickets como ruído')

# ==================== 5. GERA RELATÓRIO ====================
print(f'\n📄 Gerando relatório: {SAIDA}')
SAIDA.parent.mkdir(parents=True, exist_ok=True)

relatorio = []
for cluster_id in sorted(df['cluster'].unique()):
    if cluster_id == -1:
        continue

    sub = df[df['cluster'] == cluster_id]
    n = len(sub)
    
    # Aumenta amostra pra 15 títulos (era 10)
    amostra = sub['titulo'].head(15).tolist()
    
    # Categoria mais comum (com fallback)
    cat_mode = sub['categoria'].mode()
    cat_comum = cat_mode.iloc[0] if not cat_mode.empty else '(vazio)'

    relatorio.append({
        'cluster_id': cluster_id,
        'n_tickets': n,
        'categoria_mais_comum': cat_comum,
        'amostra_titulos': ' | '.join(amostra),
    })

df_rel = pd.DataFrame(relatorio).sort_values('n_tickets', ascending=False)
df_rel.to_csv(SAIDA, index=False)

print('\n' + '=' * 70)
print('RESUMO DOS CLUSTERS')
print('=' * 70)
for _, row in df_rel.iterrows():
    print(f'\n📦 Cluster {row["cluster_id"]} — {row["n_tickets"]} tickets')
    print(f'   Categoria mais comum: {row["categoria_mais_comum"]}')
    print(f'   Amostra: {row["amostra_titulos"][:300]}...')

# ==================== 6. VISUALIZAÇÃO ====================
print('\n📊 Gerando visualização...')
import plotly.express as px

umap_2d = umap.UMAP(n_components=2, random_state=42).fit_transform(embeddings)
df['x'] = umap_2d[:, 0]
df['y'] = umap_2d[:, 1]
df['cluster_str'] = df['cluster'].astype(str)

fig = px.scatter(
    df,
    x='x', y='y',
    color='cluster_str',
    hover_data=['id', 'titulo'],
    title='Clusters de tickets (UMAP + HDBSCAN)',
    height=700,
)
fig.write_html(RAIZ / 'relatorios' / 'clusters.html')
print(f'   Salvo em: relatorios/clusters.html')